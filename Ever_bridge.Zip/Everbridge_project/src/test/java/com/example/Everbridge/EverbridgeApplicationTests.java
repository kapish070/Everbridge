package com.example.Everbridge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EverbridgeApplicationTests {

	@Test
	void contextLoads() {
	}

}
