package com.example.modal;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;


//@Entity annotation specifies that the corresponding class is a JPA entity
@Entity
//@Table annotation provides more options to customize the mapping.
//Here the name of the table to be created in the database is explicitly mentioned as 'users'. Hence the table named 'users' will be created in the database with all the columns mapped to all the attributes in 'User' class
/* @Table(name = "WORKDAY.WORKER_DETAILS_COMM") */
@Table(name = "DEPT")

public class User
{
	
	 @Id
	    @Column(name = "DEPTNO")
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    
	    @Column(name="DNAME")
	    private String name;
	    @Column(name="LOC")
	    private String email;
	/*
	 * //@Id annotation specifies that the corresponding attribute is a primary key
	 * 
	 * @Id
	 * 
	 * @GeneratedValue(strategy = GenerationType.AUTO) //@Column annotation
	 * specifies that the attribute will be mapped to the column in the database.
	 * //Here the column name is explicitly mentioned as 'id'
	 * 
	 * @Column(name = "EMPLOYEE_ID") private int employee_id;
	 * 
	 * @Column(name = "WORK_EMAIL") private String work_email;
	 * 
	 * @Column(name = "WE_KRONOS") private char we_kronos;
	 * 
	 * @Column(name = "HOME_PHONE") private String home_phone;
	 * 
	 * @Column(name = "HP_ALERT") private char hp_alert;
	 * 
	 * @Column(name = "WORK_PHONE") private String work_phone;
	 * 
	 * @Column(name = "WP_ALERT") private char wp_alert;
	 * 
	 * @Column(name = "PERSONAL_EMAIL") private String personal_email;
	 * 
	 * @Column(name = "PE_ALERT") private char pe_alert;
	 * 
	 * @Column(name = "PE_KRONOS") private char pe_kronos;
	 * 
	 * @Column(name = "CELL_PHONE") private String cell_phone;
	 * 
	 * @Column(name = "CP_ALERT") private char cp_alert;
	 * 
	 * @Column(name = "TEXT_PHONE") private String text_phone;
	 * 
	 * @Column(name = "TXT_ALERT") private char text_alert;
	 * 
	 * @Column(name = "TXT_KRONOS") private char txt_kronos;
	 * 
	 * @Column(name = "INT_PAGER") private String int_pager;
	 * 
	 * @Column(name = "IP_ALERT") private char ip_alert;
	 * 
	 * @Column(name = "EXT_PAGER") private String ext_pager;
	 * 
	 * @Column(name = "EP_ALERT") private char ep_alert;
	 * 
	 * @Column(name = "COMM_PREF") private char comm_pref;
	 * 
	 * @Column(name = "RHS_TEXTS") private char rhs_texts;
	 * 
	 * 
	 * public User(int employee_id, String work_email, char we_kronos, String
	 * home_phone, char hp_alert, String work_phone, char wp_alert, String
	 * personal_email, char pe_alert, char pe_kronos, String cell_phone, char
	 * cp_alert, String text_phone, char text_alert, char txt_kronos, String
	 * int_pager, char ip_alert, String ext_pager, char ep_alert, char comm_pref,
	 * char rhs_texts) { super(); this.employee_id = employee_id; this.work_email =
	 * work_email; this.we_kronos = we_kronos; this.home_phone = home_phone;
	 * this.hp_alert = hp_alert; this.work_phone = work_phone; this.wp_alert =
	 * wp_alert; this.personal_email = personal_email; this.pe_alert = pe_alert;
	 * this.pe_kronos = pe_kronos; this.cell_phone = cell_phone; this.cp_alert =
	 * cp_alert; this.text_phone = text_phone; this.text_alert = text_alert;
	 * this.txt_kronos = txt_kronos; this.int_pager = int_pager; this.ip_alert =
	 * ip_alert; this.ext_pager = ext_pager; this.ep_alert = ep_alert;
	 * this.comm_pref = comm_pref; this.rhs_texts = rhs_texts; }
	 * 
	 * public int getEmployee_id() { return employee_id; } public void
	 * setEmployee_id(int employee_id) { this.employee_id = employee_id; } public
	 * String getWork_email() { return work_email; } public void
	 * setWork_email(String work_email) { this.work_email = work_email; } public
	 * char getWe_kronos() { return we_kronos; } public void setWe_kronos(char
	 * we_kronos) { this.we_kronos = we_kronos; } public String getHome_phone() {
	 * return home_phone; } public void setHome_phone(String home_phone) {
	 * this.home_phone = home_phone; } public char getHp_alert() { return hp_alert;
	 * } public void setHp_alert(char hp_alert) { this.hp_alert = hp_alert; } public
	 * String getWork_phone() { return work_phone; } public void
	 * setWork_phone(String work_phone) { this.work_phone = work_phone; } public
	 * char getWp_alert() { return wp_alert; } public void setWp_alert(char
	 * wp_alert) { this.wp_alert = wp_alert; } public String getPersonal_email() {
	 * return personal_email; } public void setPersonal_email(String personal_email)
	 * { this.personal_email = personal_email; } public char getPe_alert() { return
	 * pe_alert; } public void setPe_alert(char pe_alert) { this.pe_alert =
	 * pe_alert; } public char getPe_kronos() { return pe_kronos; } public void
	 * setPe_kronos(char pe_kronos) { this.pe_kronos = pe_kronos; } public String
	 * getCell_phone() { return cell_phone; } public void setCell_phone(String
	 * cell_phone) { this.cell_phone = cell_phone; } public char getCp_alert() {
	 * return cp_alert; } public void setCp_alert(char cp_alert) { this.cp_alert =
	 * cp_alert; } public String getText_phone() { return text_phone; } public void
	 * setText_phone(String text_phone) { this.text_phone = text_phone; } public
	 * char getText_alert() { return text_alert; } public void setText_alert(char
	 * text_alert) { this.text_alert = text_alert; } public char getTxt_kronos() {
	 * return txt_kronos; } public void setTxt_kronos(char txt_kronos) {
	 * this.txt_kronos = txt_kronos; } public String getInt_pager() { return
	 * int_pager; } public void setInt_pager(String int_pager) { this.int_pager =
	 * int_pager; } public char getIp_alert() { return ip_alert; } public void
	 * setIp_alert(char ip_alert) { this.ip_alert = ip_alert; } public String
	 * getExt_pager() { return ext_pager; } public void setExt_pager(String
	 * ext_pager) { this.ext_pager = ext_pager; } public char getEp_alert() { return
	 * ep_alert; } public void setEp_alert(char ep_alert) { this.ep_alert =
	 * ep_alert; } public char getComm_pref() { return comm_pref; } public void
	 * setComm_pref(char comm_pref) { this.comm_pref = comm_pref; } public char
	 * getRhs_texts() { return rhs_texts; } public void setRhs_texts(char rhs_texts)
	 * { this.rhs_texts = rhs_texts; }
	 * 
	 * @Override public String toString() { return "User [employee_id=" +
	 * employee_id + ", work_email=" + work_email + ", we_kronos=" + we_kronos +
	 * ", home_phone=" + home_phone + ", hp_alert=" + hp_alert + ", work_phone=" +
	 * work_phone + ", wp_alert=" + wp_alert + ", personal_email=" + personal_email
	 * + ", pe_alert=" + pe_alert + ", pe_kronos=" + pe_kronos + ", cell_phone=" +
	 * cell_phone + ", cp_alert=" + cp_alert + ", text_phone=" + text_phone +
	 * ", text_alert=" + text_alert + ", txt_kronos=" + txt_kronos + ", int_pager="
	 * + int_pager + ", ip_alert=" + ip_alert + ", ext_pager=" + ext_pager +
	 * ", ep_alert=" + ep_alert + ", comm_pref=" + comm_pref + ", rhs_texts=" +
	 * rhs_texts + "]"; }
	 * 
	 * 
	 * 
	 * 
	 */
	    public User()
	    {
	    	
	    }
	    public User(Long id, String name, String email) {
			super();
			this.id = id;
			this.name = name;
			this.email = email;
		}	
	    
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		@Override
		public String toString() {
			return "User [id=" + id + ", name=" + name + ", email=" + email + "]";
		}
		
	
}